import { useState } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Check, CreditCard, Lock, ArrowLeft, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

const plans = {
  contracts: {
    name: "Contract Library",
    price: "$4.99",
    period: "/mo · billed yearly",
    description: "Unlimited access to 50+ legal templates",
    features: [
      "Download any contract template",
      "New templates added monthly",
      "Canadian jurisdictions (all provinces Both Canadian & US jurisdictions territories)",
      "Yearly commitment · Cancel anytime",
    ],
  },
  personal: {
    name: "Personal Legal Protection",
    price: "$12.00",
    period: "/year",
    description: "Essential legal coverage for individuals",
    features: [
      "Unlimited AI case analysis",
      "Contract library access",
      "Priority email support",
      "Monthly legal newsletter",
    ],
  },
  corporate: {
    name: "Corporate Governance",
    price: "$299.00",
    period: "/month",
    description: "Comprehensive corporate legal support",
    features: [
      "Board meeting support",
      "Corporate resolutions",
      "Compliance monitoring",
      "Dedicated account manager",
    ],
  },
  counsel: {
    name: "General Counsel",
    price: "$499.00",
    period: "/month",
    description: "Your outsourced legal department",
    features: [
      "Unlimited legal consultations",
      "Contract review & drafting",
      "Employment law support",
      "24/7 emergency access",
    ],
  },
  procurement: {
    name: "Procurement Law",
    price: "$399.00",
    period: "/month",
    description: "Government contracts specialist",
    features: [
      "RFP/RFQ review & response",
      "Bid protest support",
      "Compliance advisory",
      "Contract negotiations",
    ],
  },
  // Membership Bundles
  essential: {
    name: "Essential Bundle",
    price: "$4.99",
    period: "/mo · billed yearly",
    description: "Discounts on core legal services — yearly membership",
    features: [
      "50% off Notary Services",
      "50% off Simple Wills",
      "50% off Small Claims Litigation",
      "50% off Separation & Pre-Nup Agreements",
      "15% off all Affiliate Partner services",
      "Email support",
      "Yearly commitment · Cancel anytime",
    ],
  },
  starter: {
    name: "Starter Bundle",
    price: "$6.99",
    period: "/mo · billed yearly",
    description: "Essential legal tools — yearly membership",
    features: [
      "Everything in Essential, plus:",
      "1 AI Case Analysis per month",
      "1 contract download per month (PDF or Word)",
      "Free e-Notary services",
      "Yearly commitment · Cancel anytime",
    ],
  },

  professional: {
    name: "Professional Bundle",
    price: "$9.99",
    period: "/mo · billed yearly",
    description: "Most popular for individuals — yearly membership",
    features: [
      "Up to 3 AI Case Analyses per month",
      "Up to 10 contract downloads per month (Word & PDF)",
      "Priority case processing",
      "Detailed legal memos",
      "Free in-person & e-Notary services",
      "Simple Wills included",
      "Priority email support",
      "Yearly commitment · Cancel anytime",
    ],
  },
  business: {
    name: "Executive Bundle",
    price: "$14.99",
    period: "/mo · billed yearly",
    description: "Complete legal toolkit — yearly membership",
    features: [
      "Unlimited AI Case Analyses",
      "Unlimited contract downloads (Word & PDF)",
      "Priority case processing",
      "Detailed legal memos",
      "Free in-person & e-Notary services",
      "1 consultation top-up credit/mo",
      "Dedicated support channel",
      "Choose 1: Wills, Small Claims Litigation*, or Separation/Pre-Nup",
      "Yearly commitment · Cancel anytime",
    ],
  },
};

type PlanKey = keyof typeof plans;

const Checkout = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const bundleKey = searchParams.get("bundle");
  const planParam = searchParams.get("plan");
  const langParam = searchParams.get("lang");
  const selectedKey = (bundleKey || planParam || "contracts") as PlanKey;
  const basePlan = plans[selectedKey] || plans.contracts;
  const plan =
    selectedKey === "contracts" && langParam === "fr"
      ? {
          ...basePlan,
          name: "Contract Library — Français (French)",
          price: "$5.99",
          features: [...basePlan.features, "French-language templates (+$1/mo)"],
        }
      : basePlan;
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [formData, setFormData] = useState({
    cardNumber: "",
    expiry: "",
    cvc: "",
    name: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to complete your subscription.",
        variant: "destructive",
      });
      navigate("/login?redirect=/checkout?" + (bundleKey ? "bundle=" + bundleKey : "plan=" + planParam));
      return;
    }

    setIsProcessing(true);
    
    // Simulate checkout process
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    toast({
      title: "Subscription activated!",
      description: `Welcome to ${plan.name}. Your subscription is now active.`,
    });
    
    setIsProcessing(false);
    navigate("/portal");
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || "";
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(" ") : value;
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    if (v.length >= 2) {
      return v.substring(0, 2) + "/" + v.substring(2, 4);
    }
    return v;
  };

  return (
    <Layout>
      <div className="pt-32 pb-20 min-h-screen bg-gradient-to-b from-background to-muted/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">

          <div className="grid md:grid-cols-2 gap-8">
            {/* Order Summary */}
            <Card className="h-fit">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="h-5 w-5 text-secondary" />
                  <CardTitle className="font-display">{plan.name}</CardTitle>
                </div>
                <CardDescription className="font-body">
                  {plan.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-baseline gap-1">
                  <span className="font-display text-4xl font-bold text-foreground">
                    {plan.price}
                  </span>
                  <span className="text-muted-foreground font-body">
                    {plan.period}
                  </span>
                </div>

                <Separator />

                <ul className="space-y-3">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-secondary shrink-0 mt-0.5" />
                      <span className="text-sm font-body text-muted-foreground">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>

                <Separator />

                <div className="flex justify-between items-center">
                  <span className="font-body text-muted-foreground">Total today</span>
                  <span className="font-display text-xl font-bold">{plan.price}</span>
                </div>
              </CardContent>
            </Card>

            {/* Payment Form */}
            <Card>
              <CardHeader>
                <CardTitle className="font-display flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Payment Details
                </CardTitle>
                <CardDescription className="font-body">
                  Enter your card information to complete checkout
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Cardholder Name</Label>
                    <Input
                      id="name"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input
                      id="cardNumber"
                      placeholder="4242 4242 4242 4242"
                      value={formData.cardNumber}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          cardNumber: formatCardNumber(e.target.value),
                        })
                      }
                      maxLength={19}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiry">Expiry Date</Label>
                      <Input
                        id="expiry"
                        placeholder="MM/YY"
                        value={formData.expiry}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            expiry: formatExpiry(e.target.value),
                          })
                        }
                        maxLength={5}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cvc">CVC</Label>
                      <Input
                        id="cvc"
                        placeholder="123"
                        value={formData.cvc}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            cvc: e.target.value.replace(/\D/g, "").slice(0, 4),
                          })
                        }
                        maxLength={4}
                        required
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground"
                    size="lg"
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      "Processing..."
                    ) : (
                      <>
                        <Lock className="mr-2 h-4 w-4" />
                        Subscribe Now
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-center text-muted-foreground font-body">
                    <Lock className="inline h-3 w-3 mr-1" />
                    Your payment information is secure and encrypted
                  </p>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Checkout;
